from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'exam/index.html')

def questions(request):
    return render(request,'exam/questions.html')

def result(request):
    if request.method == 'GET':
        correctans=[0,'option3','option3','option4','option3','option3']
        ans=[0]
        for i in range(1,6):
            ansno="ans"+str(i)
            ans.append(request.GET[ansno])
        print(ans)
        score=0
        for i in range(1,6):
            if ans[i] == correctans[i]:
                score=score+2
    return render(request,'exam/result.html',{'score':score})
